package top.geek_studio.chenlongcould.musicplayer;

abstract class Values {

    static final String INDEX = "index";

    static int CURRENT_INDEX = -1;

    static int FRAGMENTS_NUM = -1;

}
